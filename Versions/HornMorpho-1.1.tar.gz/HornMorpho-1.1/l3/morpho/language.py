"""
This file is part of L3Morpho.

    L3Morpho is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    L3Morpho is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with L3Morpho.  If not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------

Author: Michael Gasser <gasser@cs.indiana.edu>

Language objects, with support mainly for morphology (separate
Morphology objects defined in morphology.py).
"""

import os

FST_DIRECTORY = os.path.join(os.path.dirname(__file__),
                             os.path.pardir,
                             'FST')

from .morphology import *
# from Graphics.graphics import *
from .anal import *

class LLL:
    version = 1.0

class Language:
    '''A single Language, currently only handling morphology.'''

    def __init__(self, label, abbrev='', preproc=None, postproc=None,
                 seg_units=None,
                 citation_separate=True, msgs=None):
        """
        Set some basic language-specific attributes.

        @param preproc            Whether to pre-process input to analysis, for example,
                                  to convert non-roman to roman characters
        @param postproc           Whether to post-process output of generation, for
                                  example, to convert roman to non-roman characters
        @param seg_units          Segmentation units (graphemes)
        @param citation_separate  Whether citation form of words is separate from roots
        @param msgs               Messages in the languages (or some other)
        """
        self.label = label
        self.abbrev = abbrev or label[:3]
        self.morphology = None
        self.preproc = preproc
        self.postproc = postproc
        self.seg_units = seg_units or []
        self.citation_separate = citation_separate
        self.msgs = msgs or {}

    def __str__(self):
        return self.label

    def preprocess(self, form):
        '''Preprocess a form.'''
        if self.preproc:
            return self.preproc(form)
        else:
            return form

    def postprocess(self, form):
        '''Postprocess a form.'''
        if self.postproc:
            return self.postproc(form)
        else:
            return form

    def preprocess_file(self, filein, fileout):
        '''Preprocess forms in filein, writing them to fileout.'''
        fin = codecs.open(filein, 'r', 'utf-8')
        fout = codecs.open(fileout, 'w', 'utf-8')
        for line in fin:
            fout.write(str(self.preproc(line), 'utf-8'))
        fin.close()
        fout.close()

    def set_morphology(self, morphology, verbosity=0):
        '''Assign the Morphology object for this Language.'''
        self.morphology = morphology
        morphology.language = self
        morphology.directory = os.path.join(FST_DIRECTORY, self.abbrev)
        morphology.seg_units = self.seg_units

    def load_morpho(self, fsts=None, simplified=False, ortho=True, verbose=False):
        """Load words and FSTs for morphological analysis and generation."""
        fsts = fsts or self.morphology.pos
        print(self.msgs.get('loading', 'Loading morphological data for'), self, '...')
        # Load unanalyzed words
        self.morphology.set_words(simplify=simplified, ortho=ortho)
        # Load pre-analyzed words
        self.morphology.set_analyzed(ortho=ortho)
        for pos in fsts:
            # Load pre-analyzed words if any
            self.morphology[pos].set_analyzed(ortho=ortho)
            # Load lexical anal and gen FSTs
            self.morphology[pos].load_fst(gen=True, simplified=simplified,
                                          verbose=verbose)
            # Load guesser anal and gen FSTs
            self.morphology[pos].load_fst(gen=True, guess=True, verbose=verbose)

    ### Analyze words or sentences

    def anal_file(self, pathin, pathout=None, preproc=True, postproc=True, pos=None,
                  root=True, citation=True, gram=True, knowndict=None, guessdict=None,
                  nlines=0, start=0):
        """Analyze words in file, either writing results to pathout, storing in
        knowndict or guessdict, or printing out.
        """
        preproc = preproc and self.preproc
        postproc = postproc and self.postproc
        citation = citation and self.citation_separate
        storedict = True if knowndict != None else False
        try:
            filein = codecs.open(pathin, 'r', 'utf-8')
            # If there's no output file and no outdict, write analyses to terminal
            writeterm = True
            if storedict:
                writeterm = False
            print(self.msgs.get('analyzing', 'Analyzing words in'), pathin)
            if pathout:
                # Where the analyses are to be written
                fileout = codecs.open(pathout, 'w', 'utf-8')
                print(self.msgs.get('writing', 'Writing analysis to'), pathout)
                writeterm = False
            fsts = pos or self.morphology.pos
            n = 0
            # Save words already analyzed to avoid repetition
            saved = {}
            # If nlines is not 0, keep track of lines read
            lines = filein.readlines()
            if start or nlines:
                lines = lines[start:start+nlines]
            for line in lines:
                # Separate punctuation from words
                line = self.morphology.sep_punc(line)
                # Segment into words
                for word in line.split():
                    if word in saved:
                        # Don't bother to analyze saved words
                        analysis = saved[word]
                    else:
                        # If there's no point in analyzing the word (because it contains
                        # the wrong kind of characters or whatever), don't bother.
                        # (But only do this if preprocessing.)
                        analysis = preproc and self.morphology.trivial_anal(word)
                        if analysis:
                            analysis = self.msgs.get('Word', 'Word') + ': ' + analysis + '\n'
                        else:
                            # Attempt to analyze the word
                            form = word
                            if preproc:
                                form = self.preproc(form)
                            analyses = self.anal_word(form, fsts=fsts, guess=True, simplified=False,
                                                      root=root, stem=True, citation=citation, gram=gram, 
                                                      preproc=False, postproc=postproc, only_anal=storedict)
                            # If we're storing the analyses in a dict, don't convert them to a string
                            if storedict:
                                analysis = analyses
                            # Otherwise (for file or terminal), convert to a string
                            else:
                                if analyses:
                                    # Convert the analyses to a string
                                    analysis = self.analyses2string(word, analyses)
                                else:
                                    analysis = '?' + self.msgs.get('Word', 'Word') + ': ' + word + '\n'
                        # Store the analyses (or lack thereof)
                        saved[word] = analysis
                    # Either store the analyses in the dict or write them to the terminal or the file
                    if storedict:
                        if analysis:
                            add_anals_to_dict(self, analysis, knowndict, guessdict)
                    elif writeterm:
                        print(analysis)
                    else:
                        fileout.write(analysis + '\n')
            filein.close()
            if pathout:
                fileout.close()
        except IOError:
            print('No such file or path; try another one.')

    def analyses2string(self, word, analyses):
        '''Convert a list of analyses to a string.'''
        s = ''
        if not analyses:
            s += '?'
        s += self.msgs.get('Word', 'Word') + ': ' + word + '\n'
        for analysis in analyses:
            pos = analysis[0]
            if pos:
                pos = pos.replace('?', '')
                if pos in self.morphology:
                    s += self.morphology[pos].anal2string(analysis)
                elif self.morphology.anal2string:
                    s += self.morphology.anal2string(analysis)
        return s

    def analysis2dict(self, analysis, record_none=False, ignore=[]):
        """Convert an analysis (a FeatStruct) to a dict."""
        dct = {}
        for k, v in analysis.items():
            if isinstance(v, FeatStruct):
                v_dict = self.analysis2dict(v, record_none=record_none, ignore=ignore)
                if v_dict:
                    # Could be {}
                    dct[k] = v_dict
            elif not v:
                # v is None, False, '', or 0
                if record_none:
                    dct[k] = None
            elif k not in ignore:
                dct[k] = v
        return dct

    def anal_word(self, word, fsts=None, guess=True, simplified=False,
                  root=True, stem=True, citation=True, gram=True,
                  to_dict=False, preproc=False, postproc=False, string=False,
                  only_anal=False):
        '''Analyze a single word, trying all existing POSs, both lexical and guesser FSTs.

        [ [POS, {root|citation}, FSSet] ... ]
        '''
        preproc = preproc and self.preproc
        postproc = postproc and self.postproc
        citation = citation and self.citation_separate
        analyses = []
        fsts = fsts or self.morphology.pos
#        if not isinstance(word, str):
#            word = str(word, 'utf-8')
        if preproc:
            # Convert to roman
            form = self.preproc(word)
        else:
            form = word
        # See if the word is unanalyzable ...
        if self.morphology.is_word(form, simple=simplified):
            if only_anal:
                return []
            analyses.append(self.simp_anal([form], postproc=postproc))
        # ... or is already analyzed
        elif form in self.morphology.analyzed:
            if only_anal:
                return []
            analyses.extend(self.proc_anal_noroot(form, self.morphology.get_analyzed(form)))
        if not analyses:
            for pos in fsts:
                #... or already analyzed within a particular POS
                preanal = self.morphology[pos].get_analyzed(form, simple=simplified)
                if preanal:
                    analyses.extend(self.proc_anal(form, [preanal], pos,
                                                   show_root=root,
                                                   citation=citation, stem=stem,
                                                   simplified=False,
                                                   guess=False, postproc=postproc,
                                                   gram=gram))
            if not analyses:
                # We have to really analyze it; first try lexical FSTs for each POS
                for pos in fsts:
                    analysis = self.morphology[pos].anal(form, simplified=simplified,
                                                          to_dict=to_dict)
                    if analysis:
                        # Keep trying if an analysis is found
                        analyses.extend(self.proc_anal(form, analysis, pos,
                                                       show_root=root,
                                                       citation=citation, stem=stem,
                                                       simplified=simplified,
                                                       guess=False, postproc=postproc,
                                                       gram=gram))
                # If nothing has been found, try guesser FSTs for each POS
                if not analyses and guess:
                    # Accumulate results from all guessers
                    for pos in fsts:
                        analysis = self.morphology[pos].anal(form, guess=True,
                                                             to_dict=to_dict)
                        if analysis:
                            analyses.extend(self.proc_anal(form, analysis, pos,
                                                           show_root=root,
                                                           citation=citation,
                                                           simplified=False,
                                                           guess=True, gram=gram,
                                                           postproc=postproc))
        if string:
            # Print out stringified version
            print(self.analyses2string(word, analyses))
#            print(self.analyses2string(word, analyses).encode('utf8'))
        return analyses

    def simp_anal(self, analysis, postproc=False):
        '''Process analysis for unanalyzed cases.'''
        if postproc:
            # Convert the word to Geez.
            analysis[0] = self.postproc(analysis[0])
        return [None, analysis[0]]

    def proc_anal_noroot(self, form, analyses):
        '''Process analyses with no roots/stems.'''
        return [(analysis.get('pos'), None, None, analysis) for analysis in analyses]

    def proc_anal(self, form, analyses, pos, show_root=True, citation=True, stem=True,
                  simplified=False, guess=False, postproc=False, gram=True, string=False):
        '''Process analyses according to various options, returning a list of analysis tuples.'''
        cat = '?' + pos if guess else pos
        results = set()
        for analysis in analyses:
            root = analysis[0]
            grammar = analysis[1]
            if not show_root:
                analysis[0] = None
            if postproc and self.morphology[pos].postproc:
                self.morphology[pos].postproc(analysis)
            proc_root = analysis[0]
            for g in grammar:
                if gram: grammar = g
                else:    grammar = None
                if citation and self.morphology[pos].citation:
                    cite = self.morphology[pos].citation(root, g, simplified, guess, stem)
                    if postproc:
                        cite = self.postprocess(cite)
                else:
                    cite = None
                    # Prevent analyses with same citation form and FS
                results.add((cat, proc_root, cite, grammar))
        return list(results)
#            root_list.sort(cmp=lambda x, y: cmp(len(x), len(y)))

##class Multiling(dict):
##
##    def __init__(self, *lang_pos):
##        """Constructor takes one or more pairs: (language, pos)."""
##        dict.__init__(self, [(lang.abbrev, lang.morphology[pos]) for lang, pos in lang_pos])
##
##    def trans_word(self, form, source, dest, trace=False):
##        pass
##
##    def graphics(self):
##        start_graphics(self.values())
##
##    def load_fst(self):
##        for pos in self.values():
##            pos.load_fst()
##
##    def set_transfer_fs(self, fss):
##        '''Set the transfer FSs.'''
##        self.transfer_fss = fss
##
##    def transfer1(self, source, source_fs, target):
##        source_trans = FeatStruct()
##        source_trans[source] = source_fs
##        target_morphpos = self[target]
##        for fs in self.transfer_fss:
##            unify_fs = unify(source_trans, fs)
##            if unify_fs:
##                target_morphpos.assign_defaults(unify_fs[target])
##                return unify_fs
##
##    def transfer(self, source_lang, source_fss, target_lang):
##        """Root, FS pairs for generating target word(s)."""
##        target = []
##        for fs_set in source_fss:
##            for fs in fs_set:
##                target_fs = self.transfer1(source_lang, fs, target_lang)
##                if target_fs:
##                    # The source FS unifies with some transfer FS
##                    if target_lang in target_fs:
##                        target_glosses = target_fs[target_lang]['g'], split[',']
##                        for gloss in target_gloses:
##                            target.append((gloss, target_fs))
##        return target
                    
