This is version 1.1 of HornMorpho, a program that does morphological analysis and generation of Amharic and Tigrinya words.

To install HornMorpho, extract the files from the archive. Then go to the directory HornMorpho-1.1 and do

python setup.py install

making sure that you are using Python 3 or 3.1.

For information about using the program, see the manual that came with the distribution: horn1.1.pdf.
