This is version 2.6 of HornMorpho, a Python program that does morphological
analysis and generation of Amharic, Oromo, and Tigrinya words.
HornMorpho is part of the Processing Languages of the Global South
project (http://homes.soic.indiana.edu/gasser/plogs.html).

To install HornMorpho, extract the files from the archive. Then go to
the directory HornMorpho2.6 and do 

  python setup.py install

making sure that you are using Python 3.

For information about using the program, see the manual that came with
the distribution: horn2.6.pdf.
